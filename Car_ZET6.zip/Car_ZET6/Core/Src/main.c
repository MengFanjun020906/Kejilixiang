/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "dma.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdio.h"
#include "pca9685.h"
#include "myiic.h"
#include "math.h"
#include "myiic.h"


#define kp 0.86
#define ki 0.012
#define kd 0.005
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

int fputc(int ch,FILE *f)
{
    uint8_t temp[1]={ch};
    HAL_UART_Transmit(&huart1,temp,1,2);        //UartHandle�Ǵ��ڵľ��
}


/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */


extern uint16_t speed1;
extern uint16_t juli1;
extern uint16_t speed2;
extern uint16_t juli2;
extern uint16_t speed3;
extern uint16_t juli3;
extern uint16_t speed4;
extern uint16_t juli4;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
int Timer = 0;			//ʱ��
uint8_t speed = 0;		//��ǰPWM
short TargetSpeed = 10; //Ŀ���ٶ�
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	//int MotorSpeed=3600;//С���ٶ�
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
	SysTick_Config(SystemCoreClock / 1000);
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_TIM8_Init();
  MX_DMA_Init();
  MX_USART1_UART_Init();
  MX_TIM4_Init();
  MX_TIM5_Init();
  MX_TIM7_Init();
	IIC_Init();
  /* USER CODE BEGIN 2 */
	
//	HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_1);	//pwm�����
//	__HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_1,MotorSpeed);//ռ�ձ�Ϊ50%
//	HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_2);	//pwm�����
//	__HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_2, MotorSpeed);//ռ�ձ�Ϊ50%
//	HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_3);	//pwm�����
//	__HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_3, MotorSpeed);//ռ�ձ�Ϊ50%
//	HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_4);	//pwm�����
//	__HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_4, MotorSpeed);//ռ�ձ�Ϊ50%
//	HAL_TIM_Encoder_Start(&htim1,TIM_CHANNEL_ALL);
//	HAL_TIM_Encoder_Start(&htim2,TIM_CHANNEL_ALL);
//	HAL_TIM_Encoder_Start(&htim3,TIM_CHANNEL_ALL);
//	HAL_TIM_Encoder_Start(&htim8,TIM_CHANNEL_ALL);
	
	
	//TIM4->CCR1 = speed;           //д��PWM
	//Motor_1(GPIO_PIN_SET);		  
	//Motor_2(GPIO_PIN_RESET);	  //�����һ����ѹ������ת��������

	/*��PWM���*/
	HAL_TIM_PWM_Start(&htim4,TIM_CHANNEL_1);
	/*�򿪶�ʱ���ж�*/
	HAL_TIM_Base_Start_IT((TIM_HandleTypeDef *)&htim7);
	/*��������DMA���գ�Ĭ��DMAΪѭ��ģʽ��ǧ��Ҫ����ѭ�����*/
	HAL_UART_Receive_DMA(&huart1,(uint8_t*)&TargetSpeed,sizeof(TargetSpeed));
	/*�򿪱���������*/
	HAL_TIM_Encoder_Start(&htim3,TIM_CHANNEL_ALL);
	
	PCA9685_Init(50,0);
	 //pca_write(pca_mode1,0x0);
	
	//pca_write(pca_mode1,0x0);
	//pca_setfreq(50);//����PWMƵ��
		//pca_setpwm(0,100,10);
	//pca_setpwm(0,0,off);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	//	pca_setpwm(0,10,360);
  while (1)
  {
		int i=500,j=500;
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
		
		delay_ms(5);
//		delay_ms(10);
//		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_8,GPIO_PIN_SET);
//		delay_ms(10);
//		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_8,GPIO_PIN_RESET);
//		while(i--)
//		{
//       HAL_GPIO_WritePin(GPIOB,GPIO_PIN_5,GPIO_PIN_SET);
//		}			//SDA�ߵ�ƽ
////       
//	
////		//I2C_SDA_LOW;
//		while(j--)
//		{
//		 HAL_GPIO_WritePin(GPIOB,GPIO_PIN_5,GPIO_PIN_RESET);  
//		}
//		delay_ms(50);
			//pca_write(0xa0,0xb0);
	//	PCA9685_setPWM(0,0,2048);
			//PCA9685_setPWM(1,0,2048);
				
						delay_ms(5);
		pca_setpwm(0,0,4096);
				delay_ms(5);
		pca_setpwm(1,0,4096);
				delay_ms(5);
		pca_setpwm(2,0,4096);
				delay_ms(5);
		pca_setpwm(3,0,4096);
				delay_ms(5);
		pca_setpwm(4,0,4096);
				delay_ms(5);
		pca_setpwm(5,0,4096);
			delay_ms(5);
				pca_setpwm(6,0,4096);
			delay_ms(5);
		pca_setpwm(7,0,4096);
		delay_us(10);
		pca_setpwm(8,0,4096);
		delay_us(10);
		pca_setpwm(9,0,360);
		delay_us(10);
		pca_setpwm(10,0,360);
		delay_us(10);
		pca_setpwm(11,0,360);
		delay_us(10);
		pca_setpwm(12,0,360);
		delay_us(10);
		pca_setpwm(13,0,360);
		delay_us(10);
		pca_setpwm(14,0,360);
		delay_us(10);
		pca_setpwm(15,0,360);
		delay_us(10);
//		//PCA_Set(8,0,180,0,1);
//		delay_us(100);
		//PCA_Set(2,0,100,0,1);
//				if(Timer >= 500)
//		{
//			
//			Timer = 0;
//			//Led_Toggle();
//			//printf("speed competite\n\r");
//			//�˴�������
//		}
		//printf("������1���ݣ�%d\n������2���ݣ�%d\n������3���ݣ�%d\n������4���ݣ�%d\n\n",speed1,speed2,speed3,speed4);
		
    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

